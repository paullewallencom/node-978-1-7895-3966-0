const { add, mul, div } = require('./math');

console.log(add(30, 20)); // 50
