const config = require('./config/sample');

console.log(config.foo); // bar